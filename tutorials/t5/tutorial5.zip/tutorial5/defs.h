#ifndef DEFS_H
#define DEFS_H

#define MAX_ARRAY 256

#endif