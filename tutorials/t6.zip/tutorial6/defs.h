#ifndef DEFS_H
#define DEFS_H


#define MENU_ITEMS 3


#endif