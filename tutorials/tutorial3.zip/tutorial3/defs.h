#ifndef DEFS_H
#define DEFS_H

#define MAX_ROOMS 256
#define MAX_RES 64

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#endif