// Victor Sandru
// 101231111

#include<iostream>
#include<string>

using namespace std;

int main(){
	string name;
	cout<<"What is your name? ";
	cin >> name;
	cout << endl << "Hello " << name << "!";
	
	return 0;
}
