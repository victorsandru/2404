// Victor Sandru
// 101231111

#include<iostream>
#include<string>

using namespace std;

int main(int argc, char const *argv[])
{
    int x, y, product;
    cout << "Please enter two integers: ";
    cin >> x;
    cin >> y;
    cout << endl << "The product of " << x << " and " << y << " is " << x * y << endl; 
    return 0;
}
