Victor Sandru
101231111 

Date.cc
Date.h
defs.h
Hotel.cc
Hotel.h
main.cc
Makefile
README.md
Reservation.cc
Reservation.h
Room.cc
Room.h

Instructions:
    compile using 'make all'
    run using './main'