Victor Sandru
101231111

Instructions:
    compile using 'make all'
    run using './a3'

Files:
    all the classes and headers
    UML.pdf is the UML diagram pdf