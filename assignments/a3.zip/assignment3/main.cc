#include "Controller.h"

int main(){
    Controller control;
    control.launch();
    return 0;
}