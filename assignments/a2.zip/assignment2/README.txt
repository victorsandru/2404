Victor Sandru
101231111

Instructions:
    compile using 'make all'
    run using './main'



Files:
Album.cc
Album.h
AlbumArray.cc
AlbumArray.h
Client.cc
Client.h
Date.cc
Date.h
defs.h
main.cc
Makefile
Photo.cc
Photo.h
PhotoArray.cc
PhotoArray.h
README.txt
TestControl.cc
TestControl.h
TestView.cc
TestView.h