#include <iostream>
#include "TestControl.h"

using namespace std;

int main(){
    TestControl control;
    control.launch();
    return 0;
}